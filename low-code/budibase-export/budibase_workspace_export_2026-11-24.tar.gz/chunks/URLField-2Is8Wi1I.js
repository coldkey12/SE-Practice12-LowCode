import { cx as o, d3 as p } from "./index-B3EW84Yb.js";
import s from "./StringField-DvCzgasF.js";
function i(e, r) {
  let t = p(r, ["$$slots", "$$events", "$$legacy"]);
  s(e, o(() => t, { type: "url", autocomplete: "url" }));
}
export {
  i as default
};
