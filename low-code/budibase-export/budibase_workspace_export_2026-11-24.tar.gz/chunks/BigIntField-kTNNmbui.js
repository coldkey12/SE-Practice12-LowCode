import { bL as i, cx as r } from "./index-B3EW84Yb.js";
import o from "./StringField-DvCzgasF.js";
function a(t, e) {
  const s = i(e, ["children", "$$slots", "$$events", "$$legacy"]);
  o(t, r(() => s, { type: "bigint" }));
}
export {
  a as default
};
