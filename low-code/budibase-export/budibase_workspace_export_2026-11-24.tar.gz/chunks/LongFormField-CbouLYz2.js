import { g as he, p as o, X as Ee, j as e, o as ke, l as j, B as x, i as N, k as fe, m as me, q as $, c as ce, Y as Se, r as ue, s as Ae, aq as Te, d5 as Be, A as m, t as Me, at as Ce, a as Ne, a3 as Pe, d as G, w as xe, z as b, f as we, aS as De, a0 as Ie, n as de, H as ge, Z as qe, h as se, aa as Ve, _ as Fe, u as pe, x as ie, y as Re } from "./index-B3EW84Yb.js";
import { T as He } from "./TextArea-DV3AOS79.js";
import { F as je } from "./Field-CP2-MREb.js";
const ze = {
  bold: "text-b",
  italic: "text-italic",
  strikethrough: "text-strikethrough",
  heading: "text-h",
  "heading-smaller": "text-h",
  "heading-bigger": "text-h",
  "heading-1": "text-h",
  "heading-2": "text-h",
  "heading-3": "text-h",
  code: "code",
  quote: "quotes",
  "unordered-list": "list-bullets",
  "ordered-list": "list-numbers",
  "clean-block": "eraser",
  link: "link",
  image: "image",
  "upload-image": "image",
  table: "table",
  "horizontal-rule": "minus",
  "text-color": "text-aa",
  "text-highlight": "highlighter",
  preview: "eye",
  "side-by-side": "columns",
  fullscreen: "arrows-out",
  guide: "question",
  undo: "arrow-counter-clockwise",
  redo: "arrow-clockwise"
}, Le = (v) => Array.isArray(v?.toolbar) ? new Set(
  v.toolbar.flatMap((l) => typeof l == "object" && l !== null && typeof l.name == "string" && (l.className !== void 0 || l.icon !== void 0 || l.text !== void 0) ? [l.name] : [])
) : /* @__PURE__ */ new Set(), Xe = (v, l) => {
  for (const [u, f] of Object.entries(ze)) {
    if (l.has(u))
      continue;
    const y = v.toolbarElements?.[u]?.querySelector("i");
    y && (y.className = `ph ph-bold ph-${f}`);
  }
};
var Ye = we('<div><textarea disabled></textarea></div> <div class="budibase-color-picker-anchor svelte-gyxjiz"><!></div>', 1);
function Ke(v, l) {
  he(l, !1);
  const u = b();
  let f = o(l, "height", 12, null), y = o(l, "scroll", 8, !0), w = o(l, "easyMDEOptions", 8, null), i = o(l, "mde", 12, null), S = o(l, "id", 8, null), _ = o(l, "fullScreenOffset", 8, null), P = o(l, "disabled", 8, !1), C = b(void 0), O = b(void 0), d = b(0), E = b(0), I = b(0), A = b("text"), B = b({ text: "#d73f09", highlight: "#fff59d" }), M = null, n = null, g = null;
  const c = {
    text: {
      toolbarButtonName: "text-color",
      wrapperTag: "span",
      stylePrefix: "color",
      className: "fa fa-font",
      title: "Text Color"
    },
    highlight: {
      toolbarButtonName: "text-highlight",
      wrapperTag: "mark",
      stylePrefix: "background-color",
      className: "fa fa-paint-brush",
      title: "Highlight Color"
    }
  }, R = (t) => t.map((r) => ({ anchor: { ...r.anchor }, head: { ...r.head } })), J = (t) => t.codemirror.getSelections().some((r) => r.length > 0), Q = (t) => R(t.codemirror.listSelections()), z = (t, r) => {
    const a = t.trim();
    if (!a)
      return null;
    const s = c[r].stylePrefix;
    return typeof CSS > "u" || typeof CSS.supports != "function" || !CSS.supports(s, a) ? null : a;
  }, q = (t, r) => {
    const a = new RegExp(`${c[r].stylePrefix}\\s*:\\s*([^;"']+)`, "i"), s = t.match(a);
    return s?.[1] ? z(s[1], r) : null;
  }, U = (t) => {
    const r = { text: [], highlight: [] }, a = /<(\/?)(span|mark)\b[^>]*>/gi;
    for (const s of t.matchAll(a)) {
      const k = s[0], T = s[1] === "/", h = s[2].toLowerCase() === "mark" ? "highlight" : "text";
      if (T) {
        r[h].pop();
        continue;
      }
      const V = q(k, h);
      V && r[h].push(V);
    }
    return {
      text: r.text.length ? r.text[r.text.length - 1] : null,
      highlight: r.highlight.length ? r.highlight[r.highlight.length - 1] : null
    };
  }, p = (t, r) => {
    const a = { text: null, highlight: null }, s = t.lastIndexOf("<", r);
    if (s < 0 || t.lastIndexOf(">", r - 1) > s)
      return a;
    const T = t.indexOf(">", s);
    if (T < 0)
      return a;
    const h = t.slice(s, T + 1);
    return /^<span\b/i.test(h) && (a.text = q(h, "text")), /^<mark\b/i.test(h) && (a.highlight = q(h, "highlight")), a;
  }, L = (t, r, a) => {
    const k = t.toolbarElements?.[c[r].toolbarButtonName]?.querySelector("i");
    if (k) {
      if (!a) {
        k.style.removeProperty("color");
        return;
      }
      k.style.color = a;
    }
  }, H = (t) => {
    const r = t.codemirror.getCursor("head"), a = t.codemirror.indexFromPos(r), s = t.codemirror.getValue(), k = s.slice(0, a), T = U(k), h = p(s, a), V = h.text || T.text, F = h.highlight || T.highlight;
    L(t, "text", V), L(t, "highlight", F);
  }, ee = () => {
    !i() || !J(i()) || (n = Q(i()));
  }, X = () => {
    i() && (ee(), H(i()));
  }, Y = (t) => {
    g !== t && (g && g.codemirror.off("cursorActivity", X), t.codemirror.on("cursorActivity", X), g = t);
  }, K = async (t, r) => {
    const a = t, s = Q(a), k = J(a) ? s : n || s;
    M = R(k), x(A, r);
    const T = c[r].toolbarButtonName, h = a.toolbarElements?.[T];
    if (h) {
      const F = h.getBoundingClientRect();
      x(d, Math.round(F.left + F.width / 2)), x(E, Math.round(F.bottom));
    }
    x(I, e(I) + 1), await De(), e(O)?.querySelector(".preview")?.click();
  }, te = (t, r) => {
    if (!M || !i())
      return;
    const a = z(t, r);
    if (!a)
      return;
    i().codemirror.focus(), i().codemirror.setSelections(M);
    const s = i().codemirror.getSelections(), k = s?.some((ae) => ae.length > 0);
    if (!s?.length || !k) {
      M = null;
      return;
    }
    const { wrapperTag: T, stylePrefix: h } = c[r], V = `${h}: ${a};`, F = s.map((ae) => `<${T} style="${V}">${ae}</${T}>`);
    i().codemirror.replaceSelections(F), M = null;
  }, le = (t) => {
    const r = t.detail?.trim();
    r && (x(B, { ...e(B), [e(A)]: r }), te(r, e(A)), i() && H(i()));
  }, re = {
    name: c.text.toolbarButtonName,
    action: (t) => K(t, "text"),
    className: c.text.className,
    title: c.text.title
  }, D = {
    name: c.highlight.toolbarButtonName,
    action: (t) => K(t, "highlight"),
    className: c.highlight.className,
    title: c.highlight.title
  }, oe = [
    "bold",
    "italic",
    "heading",
    "|",
    "quote",
    "unordered-list",
    "ordered-list",
    "|",
    "link",
    "image",
    "|",
    re,
    D,
    "|",
    "preview",
    "side-by-side",
    "fullscreen",
    "|",
    "guide"
  ], ne = (t) => t?.toolbar !== void 0 ? t.toolbar : oe;
  Ee(async () => {
    f(f() || "200px");
    const { default: t } = await import("./easymde-FiNPjx9Q.js").then((r) => r.e);
    i(new t({
      element: e(C),
      spellChecker: !1,
      status: !1,
      unorderedListStyle: "-",
      maxHeight: y() ? f() : void 0,
      minHeight: y() ? void 0 : f(),
      ...w(),
      autoDownloadFontAwesome: !1,
      toolbar: ne(w())
    })), Xe(i(), Le(w())), Y(i()), H(i());
  }), ke(() => {
    g && g.codemirror.off("cursorActivity", X), i()?.toTextArea();
  });
  const _e = (t) => {
    let r = "";
    return r += `--fullscreen-offset-x:${t?.x || "0px"};`, r += `--fullscreen-offset-y:${t?.y || "0px"};`, r;
  };
  j(() => N(_()), () => {
    x(u, _e(_()));
  }), fe(), me();
  var be = Ye(), Z = $(be);
  let ye;
  var ve = ce(Z);
  Se(ve, (t) => x(C, t), () => e(C)), ue(Z);
  var W = Ae(Z, 2), Oe = ce(W);
  Te(Oe, () => e(I), (t) => {
    Be(t, {
      get value() {
        return e(B), e(A), m(() => e(B)[e(A)]);
      },
      size: "S",
      $$events: { change: le }
    });
  }), ue(W), Se(W, (t) => x(O, t), () => e(O)), Me(
    (t) => {
      Ce(Z, e(u)), ye = Ne(Z, 1, "svelte-gyxjiz", null, ye, t), Pe(ve, "id", S()), Ce(W, `left:${e(d)}px;top:${e(E)}px;`);
    },
    [() => ({ disabled: P() })]
  ), G(v, be), xe();
}
function Ze(v, l) {
  he(l, !1);
  let u = o(l, "value", 8, null), f = o(l, "height", 8, null), y = o(l, "placeholder", 8, null), w = o(l, "id", 8, null), i = o(l, "fullScreenOffset", 8, null), S = o(l, "disabled", 8, !1), _ = o(l, "readonly", 8, !1), P = o(l, "easyMDEOptions", 24, () => ({}));
  const C = Ie();
  let O, d = b(null), E = null;
  const I = (g) => {
    E !== g && (E && E.codemirror.off("blur", B), g.codemirror.on("blur", B), E = g);
  }, A = (g, c) => {
    g && c !== O && g.value(c ?? "");
  }, B = () => {
    e(d) && (O = e(d).value(), C("change", O));
  };
  ke(() => {
    E && E.codemirror.off("blur", B);
  }), j(() => (e(d), N(u())), () => {
    A(e(d), u());
  }), j(() => e(d), () => {
    e(d) && I(e(d));
  }), j(
    () => (N(_()), N(S()), e(d)),
    () => {
      (_() || S()) && e(d) && e(d).togglePreview?.();
    }
  ), fe(), me();
  var M = de(), n = $(M);
  Te(n, f, (g) => {
    {
      let c = ge(() => (N(u()), N(y()), N(P()), N(S()), N(_()), m(() => ({
        initialValue: u(),
        placeholder: y(),
        ...P(),
        toolbar: S() || _() ? !1 : P()?.toolbar
      }))));
      Ke(g, {
        scroll: !0,
        get height() {
          return f();
        },
        get id() {
          return w();
        },
        get fullScreenOffset() {
          return i();
        },
        get disabled() {
          return S();
        },
        get easyMDEOptions() {
          return e(c);
        },
        get mde() {
          return e(d);
        },
        set mde(R) {
          x(d, R);
        },
        $$legacy: !0
      });
    }
  }), G(v, M), xe();
}
var Ge = we("<div><!></div>");
function Je(v, l) {
  let u = o(l, "value", 8, ""), f = o(l, "placeholder", 8, null), y = o(l, "disabled", 8, !1), w = o(l, "readonly", 8, !1), i = o(l, "height", 8, null), S = o(l, "id", 8, null), _ = o(l, "fullScreenOffset", 8, null), P = o(l, "easyMDEOptions", 8, null);
  var C = Ge(), O = ce(C);
  Ze(O, {
    get value() {
      return u();
    },
    get placeholder() {
      return f();
    },
    get height() {
      return i();
    },
    get id() {
      return S();
    },
    get fullScreenOffset() {
      return _();
    },
    get disabled() {
      return y();
    },
    get easyMDEOptions() {
      return P();
    },
    get readonly() {
      return w();
    },
    $$events: {
      change(d) {
        qe.call(this, l, d);
      }
    }
  }), ue(C), G(v, C);
}
function $e(v, l) {
  he(l, !1);
  const u = () => ie(J, "$component", w), f = () => ie(Q, "$layout", w), y = () => ie(R, "$context", w), [w, i] = Re(), S = b();
  let _ = o(l, "field", 8), P = o(l, "label", 8), C = o(l, "placeholder", 8), O = o(l, "disabled", 8, !1), d = o(l, "readonly", 8, !1), E = o(l, "validation", 8), I = o(l, "defaultValue", 8, ""), A = o(l, "format", 8, "auto"), B = o(l, "onChange", 8), M = o(l, "helpText", 8, null), n = b(), g = b(), c = b();
  const R = se("context"), J = se("component"), Q = se("layout"), z = Ve(u());
  Fe("component", z);
  let q = b();
  const U = (p) => {
    const L = e(g).setValue(p.detail);
    B() && L && B()({ value: p.detail });
  };
  j(() => (N(A()), e(c)), () => {
    x(S, A() === "rich" || A() !== "plain" && e(c)?.useRichText);
  }), j(() => u(), () => {
    x(q, u().styles?.normal?.height || "150px"), z.set({
      ...u(),
      styles: {
        ...u().styles,
        normal: { ...u().styles.normal, height: void 0 }
      }
    });
  }), fe(), me(), je(v, {
    get label() {
      return P();
    },
    get field() {
      return _();
    },
    get disabled() {
      return O();
    },
    get readonly() {
      return d();
    },
    get validation() {
      return E();
    },
    get defaultValue() {
      return I();
    },
    get helpText() {
      return M();
    },
    type: "longform",
    get fieldState() {
      return e(n);
    },
    set fieldState(p) {
      x(n, p);
    },
    get fieldApi() {
      return e(g);
    },
    set fieldApi(p) {
      x(g, p);
    },
    get fieldSchema() {
      return e(c);
    },
    set fieldSchema(p) {
      x(c, p);
    },
    children: (p, L) => {
      var H = de(), ee = $(H);
      {
        var X = (Y) => {
          var K = de(), te = $(K);
          {
            var le = (D) => {
              {
                let oe = ge(() => (f(), m(() => ({ x: f().screenXOffset, y: f().screenYOffset })))), ne = ge(() => (y(), m(() => ({
                  hideIcons: y().device.mobile ? ["side-by-side", "guide"] : []
                }))));
                Je(D, {
                  get value() {
                    return e(n), m(() => e(n).value);
                  },
                  get disabled() {
                    return e(n), m(() => e(n).disabled);
                  },
                  get readonly() {
                    return e(n), m(() => e(n).readonly);
                  },
                  get error() {
                    return e(n), m(() => e(n).error);
                  },
                  get id() {
                    return e(n), m(() => e(n).fieldId);
                  },
                  get placeholder() {
                    return C();
                  },
                  get height() {
                    return e(q);
                  },
                  get fullScreenOffset() {
                    return e(oe);
                  },
                  get easyMDEOptions() {
                    return e(ne);
                  },
                  $$events: { change: U }
                });
              }
            }, re = (D) => {
              He(D, {
                get value() {
                  return e(n), m(() => e(n).value);
                },
                get disabled() {
                  return e(n), m(() => e(n).disabled);
                },
                get readonly() {
                  return e(n), m(() => e(n).readonly);
                },
                get error() {
                  return e(n), m(() => e(n).error);
                },
                get id() {
                  return e(n), m(() => e(n).fieldId);
                },
                get placeholder() {
                  return C();
                },
                get minHeight() {
                  return e(q);
                },
                $$events: { change: U }
              });
            };
            pe(te, (D) => {
              e(S) ? D(le) : D(re, !1);
            });
          }
          G(Y, K);
        };
        pe(ee, (Y) => {
          e(n) && Y(X);
        });
      }
      G(p, H);
    },
    $$slots: { default: !0 },
    $$legacy: !0
  }), xe(), i();
}
export {
  $e as default
};
