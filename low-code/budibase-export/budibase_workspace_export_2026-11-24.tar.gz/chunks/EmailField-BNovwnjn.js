import { cx as p, d3 as r } from "./index-B3EW84Yb.js";
import s from "./StringField-DvCzgasF.js";
function i(e, t) {
  let o = r(t, ["$$slots", "$$events", "$$legacy"]);
  s(e, p(() => o, { type: "email", autocomplete: "email" }));
}
export {
  i as default
};
