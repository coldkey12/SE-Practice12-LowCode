import { bL as s, g as i, m as n, cx as o, i as c, b5 as t, A as l, w as d } from "./index-B3EW84Yb.js";
import _ from "./BBReferenceField-DMefS-3C.js";
function B(a, e) {
  const r = s(e, ["children", "$$slots", "$$events", "$$legacy"]), p = s(r, []);
  i(e, !1), n(), _(a, o(() => p, {
    get type() {
      return c(t), l(() => t.BB_REFERENCE_SINGLE);
    }
  })), d();
}
export {
  B as default
};
