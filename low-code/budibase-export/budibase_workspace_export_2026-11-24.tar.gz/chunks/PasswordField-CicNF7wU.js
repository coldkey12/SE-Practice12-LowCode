import { bL as o, cx as p } from "./index-B3EW84Yb.js";
import t from "./StringField-DvCzgasF.js";
function d(s, r) {
  const e = o(r, ["children", "$$slots", "$$events", "$$legacy"]);
  t(s, p(() => e, { type: "password" }));
}
export {
  d as default
};
