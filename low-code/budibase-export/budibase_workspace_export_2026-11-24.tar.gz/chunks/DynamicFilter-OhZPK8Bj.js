import { g as it, p as l, a0 as Ot, l as V, j as e, B as i, i as n, k as pt, m as ut, q as X, c as _, a1 as _a, r as m, s as k, I as st, Y as Ht, a8 as ya, u as U, A as o, v as Oa, aC as wa, t as Ce, a as Ge, d as h, ci as Kt, n as ie, T as Ut, b as nt, e as gt, cP as Ta, Z as ot, U as qt, a3 as jt, a2 as Aa, w as dt, z as b, H as Q, f as re, ch as ra, aU as na, y as It, cz as Fa, _ as Ea, o as sa, cQ as Ct, $ as $t, x as Ze, cR as Va, cS as xa, cT as Ca, cU as La, aG as Yt, a4 as kt, a5 as Nt, E as ft, at as ea, V as ta, cV as oa, aa as At, aT as ia, bM as Pa, cj as Sa, D as Ra, G as ka, aN as tt, bx as ua, bE as Na, cm as da, ag as ca, cW as Wt, ay as va, ak as Lt, b5 as T, cX as Ba, cY as Ma, bn as Gt, h as Bt, b4 as za, au as Ia, cZ as aa, aj as Da, cI as Wa, ck as Pt, F as Ga, bm as Ua, c_ as qa, ar as ja, cu as Ha, C as Ya, av as Qa, ai as Ja, c$ as Za, d0 as Xa } from "./index-B3EW84Yb.js";
import { f as Ka, D as $a } from "./users-CdTFkBWy.js";
import { M as el } from "./Multiselect-sBSJmhfH.js";
import tl from "./Button-Ct52-Aw9.js";
var al = re('<li role="option" aria-selected="true" tabindex="0"><span class="spectrum-Menu-itemLabel svelte-1mzui26"> </span> <div class="check svelte-1mzui26"><!></div></li>'), ll = re('<li class="spectrum-Menu-item empty svelte-1mzui26">No results</li>'), rl = re('<div><ul class="spectrum-Menu" role="listbox"><!></ul></div>'), nl = re('<div><div><input type="text" class="spectrum-Textfield-input spectrum-InputGroup-input svelte-1mzui26"/></div> <button class="spectrum-Picker spectrum-Picker--sizeM spectrum-InputGroup-button" tabindex="-1" aria-haspopup="true"><!></button></div> <!>', 1);
function sl(ne, t) {
  it(t, !1);
  const u = b();
  let g = l(t, "value", 24, () => {
  }), K = l(t, "id", 24, () => {
  }), D = l(t, "placeholder", 8, "Choose an option or type"), S = l(t, "disabled", 8, !1), a = l(t, "readonly", 8, !1), q = l(t, "options", 24, () => []), d = l(t, "getOptionLabel", 8, (L) => `${L}`), N = l(t, "getOptionValue", 8, (L) => `${L}`), W = l(t, "popoverAutoWidth", 8, !1), $ = l(t, "wrapText", 8, !1);
  const j = Ot();
  let x = b(!1), M = b(!1), z = b(), f = b("");
  const R = (L) => L == null ? "" : String(L).toLowerCase(), se = (L, F = !0) => {
    j("change", L), i(x, !F);
  }, H = (L) => {
    i(f, L.currentTarget.value), j("type", e(f)), i(x, !0);
  }, y = (L) => {
    i(f, L), j("pick", L), se(L);
  };
  V(() => (e(M), n(g())), () => {
    e(M) || i(f, g() || "");
  }), V(
    () => (e(f), n(q()), n(d()), n(N())),
    () => {
      i(u, !e(f).trim() || !q()?.length ? q() : q().filter((L) => {
        const F = R(d()(L)), ue = R(N()(L)), O = R(e(f));
        return F.includes(O) || ue.includes(O);
      }));
    }
  ), pt(), ut();
  var B = nl(), C = X(B);
  let c;
  var A = _(C);
  let I;
  var p = _(A);
  _a(p), m(A);
  var me = k(A, 2), we = _(me);
  st(we, { name: "caret-down", size: "S" }), m(me), m(C), Ht(C, (L) => i(z, L), () => e(z));
  var Le = k(C, 2);
  {
    let L = Q(() => W() ? "min-to-anchor" : "fixed-to-anchor"), F = Q(() => W() ? 400 : void 0);
    ya(Le, {
      get anchor() {
        return e(z);
      },
      get open() {
        return e(x);
      },
      get align() {
        return n(Kt), o(() => Kt.Left);
      },
      get widthMode() {
        return e(L);
      },
      get maxWidth() {
        return e(F);
      },
      closeOnScroll: !0,
      $$events: { close: () => i(x, !1) },
      children: (ue, O) => {
        var w = rl();
        let ee;
        var fe = _(w), de = _(fe);
        {
          var Te = (ce) => {
            var Ae = ie(), at = X(Ae);
            Ut(at, 1, () => e(u), qt, (Xe, Ue) => {
              var xe = al();
              let s;
              var v = _(xe), te = _(v, !0);
              m(v);
              var ve = k(v, 2), ge = _(ve);
              st(ge, { name: "check", size: "S" }), m(ve), m(xe), Ce(
                (J, Ne) => {
                  s = Ge(xe, 1, "spectrum-Menu-item svelte-1mzui26", null, s, J), nt(te, Ne);
                },
                [
                  () => ({ "is-selected": N()(e(Ue)) === g() }),
                  () => (n(d()), e(Ue), o(() => d()(e(Ue))))
                ]
              ), gt("mousedown", xe, Ta(function(J) {
                ot.call(this, t, J);
              })), gt("click", xe, () => y(N()(e(Ue)))), h(Xe, xe);
            }), h(ce, Ae);
          }, be = (ce) => {
            var Ae = ll();
            h(ce, Ae);
          };
          U(de, (ce) => {
            e(u), o(() => e(u) && Array.isArray(e(u)) && e(u).length) ? ce(Te) : ce(be, !1);
          });
        }
        m(fe), m(w), Oa(w, (ce, Ae) => wa?.(ce, Ae), () => () => {
          i(x, !1);
        }), Ce((ce) => ee = Ge(w, 1, "popover-content svelte-1mzui26", null, ee, ce), [
          () => ({ "auto-width": W(), "wrap-text": $() })
        ]), h(ue, w);
      },
      $$slots: { default: !0 }
    });
  }
  Ce(
    (L, F) => {
      c = Ge(C, 1, "spectrum-InputGroup svelte-1mzui26", null, c, L), I = Ge(A, 1, "spectrum-Textfield spectrum-InputGroup-textfield svelte-1mzui26", null, I, F), jt(p, "id", K()), Aa(p, e(f)), jt(p, "placeholder", D() || ""), p.disabled = S(), p.readOnly = a(), me.disabled = S();
    },
    [
      () => ({
        "is-focused": e(x) || e(M),
        "is-disabled": S()
      }),
      () => ({
        "is-disabled": S(),
        "is-focused": e(x) || e(M)
      })
    ]
  ), gt("focus", p, () => i(M, !0)), gt("blur", p, () => {
    i(M, !1), e(f) !== (g() || "") && j("change", e(f)), j("blur");
  }), gt("input", p, H), gt("click", me, () => i(x, !e(x))), h(ne, B), dt();
}
function la(ne, t) {
  it(t, !1);
  let u = l(t, "value", 28, () => {
  }), g = l(t, "label", 24, () => {
  }), K = l(t, "disabled", 8, !1), D = l(t, "readonly", 8, !1), S = l(t, "labelPosition", 8, "above"), a = l(t, "error", 24, () => {
  }), q = l(t, "placeholder", 8, "Choose an option or type"), d = l(t, "options", 24, () => []), N = l(t, "helpText", 24, () => {
  }), W = l(t, "required", 8, !1), $ = l(t, "popoverAutoWidth", 8, !1), j = l(t, "wrapText", 8, !1);
  const x = (y, B) => {
    if (y && typeof y == "object" && B in y) {
      const c = y[B];
      return typeof c == "string" ? c : typeof c == "number" || typeof c == "boolean" ? String(c) : "";
    }
    return y == null ? "" : String(y);
  }, M = (y) => x(y, "label"), z = (y) => x(y, "value");
  let f = l(t, "getOptionLabel", 8, M), R = l(t, "getOptionValue", 8, z);
  const se = Ot(), H = (y) => {
    u(y.detail), se("change", y.detail);
  };
  ut(), ra(ne, {
    get helpText() {
      return N();
    },
    get label() {
      return g();
    },
    get labelPosition() {
      return S();
    },
    get error() {
      return a();
    },
    get required() {
      return W();
    },
    children: (y, B) => {
      sl(y, {
        get disabled() {
          return K();
        },
        get value() {
          return u();
        },
        get options() {
          return d();
        },
        get placeholder() {
          return q();
        },
        get readonly() {
          return D();
        },
        get getOptionLabel() {
          return f();
        },
        get getOptionValue() {
          return R();
        },
        get popoverAutoWidth() {
          return $();
        },
        get wrapText() {
          return j();
        },
        $$events: {
          change: H,
          pick(C) {
            ot.call(this, t, C);
          },
          type(C) {
            ot.call(this, t, C);
          },
          blur(C) {
            ot.call(this, t, C);
          }
        }
      });
    },
    $$slots: { default: !0 }
  }), dt();
}
function ga(ne, t) {
  it(t, !1);
  const u = b();
  let g = l(t, "value", 28, () => []), K = l(t, "label", 24, () => {
  }), D = l(t, "disabled", 8, !1), S = l(t, "readonly", 8, !1), a = l(t, "labelPosition", 8, "above"), q = l(t, "error", 24, () => {
  }), d = l(t, "placeholder", 24, () => {
  }), N = l(t, "options", 24, () => []), W = l(t, "getOptionLabel", 8, (A) => A), $ = l(t, "getOptionValue", 8, (A) => A), j = l(t, "sort", 8, !1), x = l(t, "autoWidth", 8, !1), M = l(t, "popoverAutoWidth", 8, !1), z = l(t, "autocomplete", 8, !1), f = l(t, "searchTerm", 28, () => {
  }), R = l(t, "customPopoverHeight", 24, () => {
  }), se = l(t, "helpText", 24, () => {
  }), H = l(t, "onOptionMouseenter", 8, () => {
  }), y = l(t, "onOptionMouseleave", 8, () => {
  }), B = l(t, "searchPlaceholder", 24, () => {
  });
  const C = Ot(), c = (A) => {
    g(A.detail), C("change", A.detail);
  };
  V(() => n(g()), () => {
    i(u, g() && !Array.isArray(g()) ? [g()] : g());
  }), pt(), ut(), ra(ne, {
    get helpText() {
      return se();
    },
    get label() {
      return K();
    },
    get labelPosition() {
      return a();
    },
    get error() {
      return q();
    },
    children: (A, I) => {
      el(A, {
        get disabled() {
          return D();
        },
        get readonly() {
          return S();
        },
        get options() {
          return N();
        },
        get placeholder() {
          return d();
        },
        get sort() {
          return j();
        },
        get getOptionLabel() {
          return W();
        },
        get getOptionValue() {
          return $();
        },
        get autoWidth() {
          return x();
        },
        get popoverAutoWidth() {
          return M();
        },
        get autocomplete() {
          return z();
        },
        get customPopoverHeight() {
          return R();
        },
        get onOptionMouseenter() {
          return H();
        },
        get onOptionMouseleave() {
          return y();
        },
        get searchPlaceholder() {
          return B();
        },
        get value() {
          return e(u);
        },
        set value(p) {
          i(u, p);
        },
        get searchTerm() {
          return f();
        },
        set searchTerm(p) {
          f(p);
        },
        $$events: {
          change: c,
          click(p) {
            ot.call(this, t, p);
          }
        },
        $$legacy: !0
      });
    },
    $$slots: { default: !0 }
  }), dt();
}
const ol = "drawer-container", St = At([]), wt = At(!1), Rt = At(!0), Mt = At(null), zt = At(null);
let Tt = null;
const il = () => {
  const ne = document.getElementsByClassName(ol)[0];
  if (Tt || !(ne instanceof HTMLElement))
    return;
  Tt = new ResizeObserver((u) => {
    if (!u?.[0])
      return;
    const g = u[0].target.getBoundingClientRect();
    Mt.set(g.left), zt.set(g.width);
  }), Tt.observe(ne);
  const t = ne.getBoundingClientRect();
  Mt.set(t.left), zt.set(t.width);
}, ul = () => {
  ia(St).length || (Tt?.disconnect(), Tt = null, wt.set(!1), Rt.set(!0), Mt.set(null), zt.set(null));
};
var dl = re('<div class="text svelte-1189ub1"> </div>'), cl = re('<div class="drawer-wrapper"><div></div> <div><header class="svelte-1189ub1"><!> <div class="buttons svelte-1189ub1"><!> <!> <!></div></header> <!> <div></div></div></div>');
function vl(ne, t) {
  const u = na(t);
  it(t, !1);
  const g = () => Ze(St, "$openDrawers", d), K = () => Ze(Va, "$overlayStack", d), D = () => Ze(Mt, "$drawerLeft", d), S = () => Ze(zt, "$drawerWidth", d), a = () => Ze(wt, "$modal", d), q = () => Ze(Rt, "$resizable", d), [d, N] = It();
  let W = l(t, "title", 8, ""), $ = l(t, "forceModal", 8, !1), j = l(t, "zIndex", 24, () => {
  });
  const x = Ot(), M = 11;
  let z = b(!1), f = Fa(), R = b(0), se = b(-1), H = b(Ct), y = b("");
  const B = (O, w, ee, fe, de) => {
    let Te = `
      --scale-factor: ${me(O)};
      --spacing: ${M}px;
      ${de != null ? `z-index: ${de};` : ""}
    `;
    return fe || w == null || ee == null ? Te : `
      ${Te}
      left: ${w + M}px;
      width: ${ee - 2 * M}px;
    `;
  };
  function C() {
    e(z) || ($() && (wt.set(!0), Rt.set(!1)), il(), i(z, !0), x("drawerShow", f), St.update((O) => [...O, f]), xa(f));
  }
  function c() {
    e(z) && (i(z, !1), x("drawerHide", f), St.update((O) => O.filter((w) => w !== f)), Ca(f), ul());
  }
  Ea("drawer", { hide: c, show: C, modal: wt, resizable: Rt });
  const A = (O) => O < 0.5 ? 2 * O * O : 1 - Math.pow(-2 * O + 2, 2) / 2, I = (O) => ({
    duration: 260,
    css: (w) => {
      const ee = A(w);
      return `
          transform: translateY(calc(${(1 - ee) * 200}px - 800px * (1 - var(--scale-factor))));
          opacity: ${ee};
        `;
    }
  }), p = (O) => ({
    duration: 260,
    css: (w) => `opacity: ${A(w)};`
  }), me = (O) => 1 - (1 - 1 / (O * O + 1)) * 0.1;
  sa(() => {
    e(z) && c();
  }), V(() => g(), () => {
    i(R, g().length - g().indexOf(f) - 1);
  }), V(() => K(), () => {
    i(se, K().indexOf(f));
  }), V(() => (n(j()), e(se), Ct), () => {
    i(H, j() ?? (e(se) === -1 ? Ct : Ct + e(se)));
  }), V(
    () => (e(R), D(), S(), a(), e(H)),
    () => {
      i(y, B(e(R), D(), S(), a(), e(H)));
    }
  ), pt();
  var we = { show: C, hide: c };
  ut();
  var Le = ie(), L = X(Le);
  {
    var F = (O) => {
      La(O, {
        target: ".modal-container",
        children: (w, ee) => {
          var fe = cl(), de = _(fe);
          let Te;
          var be = k(de, 2);
          let ce;
          var Ae = _(be), at = _(Ae);
          {
            var Xe = (Y) => {
              var Z = ie(), _e = X(Z);
              ft(_e, t, "title", {}, null), h(Y, Z);
            }, Ue = (Y) => {
              var Z = dl(), _e = _(Z, !0);
              m(Z), Ce(() => nt(_e, W() || "Bindings")), h(Y, Z);
            };
            U(at, (Y) => {
              o(() => u.title) ? Y(Xe) : Y(Ue, !1);
            });
          }
          var xe = k(at, 2), s = _(xe);
          Yt(s, {
            secondary: !0,
            quiet: !0,
            $$events: { click: c },
            children: (Y, Z) => {
              kt();
              var _e = Nt("Cancel");
              h(Y, _e);
            },
            $$slots: { default: !0 }
          });
          var v = k(s, 2);
          ft(v, t, "buttons", {}, null);
          var te = k(v, 2);
          {
            var ve = (Y) => {
              oa(Y, {
                size: "M",
                quiet: !0,
                get selected() {
                  return a();
                },
                $$events: { click: () => wt.set(!a()) },
                children: (Z, _e) => {
                  {
                    let Be = Q(() => a() ? "arrows-in-simple" : "arrows-out-simple");
                    st(Z, {
                      get name() {
                        return e(Be);
                      },
                      size: "S"
                    });
                  }
                },
                $$slots: { default: !0 }
              });
            };
            U(te, (Y) => {
              q() && Y(ve);
            });
          }
          m(xe), m(Ae);
          var ge = k(Ae, 2);
          ft(ge, t, "body", {}, null);
          var J = k(ge, 2);
          let Ne;
          m(be), m(fe), Ce(
            (Y, Z, _e) => {
              Te = Ge(de, 1, "underlay svelte-1189ub1", null, Te, Y), ea(de, `z-index: ${e(H) - 1}`), ce = Ge(be, 1, "drawer svelte-1189ub1", null, ce, Z), ea(be, e(y)), Ne = Ge(J, 1, "overlay svelte-1189ub1", null, Ne, _e);
            },
            [
              () => ({ hidden: !a() }),
              () => ({ stacked: e(R) > 0, modal: a() }),
              () => ({ hidden: a() || e(R) === 0 })
            ]
          ), ta(3, de, () => p), ta(3, be, () => I), h(w, fe);
        },
        $$slots: { default: !0 }
      });
    };
    U(L, (O) => {
      e(z) && O(F);
    });
  }
  h(ne, Le), $t(t, "show", C), $t(t, "hide", c);
  var ue = dt(we);
  return N(), ue;
}
var gl = re('<div class="user-control"><!></div>');
function fl(ne, t) {
  it(t, !1);
  const u = () => Ze(e(D), "$fetch", g), [g, K] = It(), D = b(), S = b(), a = b(), q = b(), d = b();
  let N = l(t, "API", 24, Pa), W = l(t, "value", 8, null), $ = l(t, "disabled", 8, !1), j = l(t, "multiselect", 8, !1), x = b(null), M = "", z = b({}), f = /* @__PURE__ */ new Set();
  const R = Sa("picker"), se = Na(
    (c) => {
      c !== M && (M = c, e(D).update({ query: c ? { string: { email: c } } : {} }));
    },
    250
  ), H = async (c) => {
    const A = c.filter((p) => !f.has(p));
    if (!A.length)
      return;
    A.forEach((p) => f.add(p));
    const I = await Ka(N(), A);
    A.forEach((p) => f.delete(p)), Object.keys(I).length && i(z, { ...e(z), ...I });
  }, y = (c, A) => {
    const I = new Set(A);
    return [...c].sort((p, me) => {
      const we = I.has(p._id), Le = I.has(me._id);
      return we !== Le ? we ? -1 : 1 : (p.email || "").localeCompare(me.email || "");
    });
  };
  V(() => n(N()), () => {
    Ra(
      i(D, ka({
        API: N(),
        datasource: { type: "user" },
        options: { limit: 100 }
      })),
      "$fetch",
      g
    );
  }), V(() => e(x), () => {
    se(e(x) || "");
  }), V(() => n(W()), () => {
    i(S, W() ? Array.isArray(W()) ? W() : [W()] : []);
  }), V(() => u(), () => {
    i(a, new Set((u().rows || []).map((c) => c._id)));
  }), V(() => (e(S), e(a), e(z)), () => {
    H(e(S).filter((c) => !e(a).has(c) && !e(z)[c]));
  }), V(
    () => (u(), e(z), e(S), e(a)),
    () => {
      i(q, y(
        [
          ...u().rows || [],
          ...Object.values(e(z)).filter((c) => e(S).includes(c._id) && !e(a).has(c._id))
        ],
        e(S)
      ));
    }
  ), V(() => (n(j()), tt), () => {
    i(d, j() ? ga : tt);
  }), pt(), ut();
  var B = gl(), C = _(B);
  ua(C, () => e(d), (c, A) => {
    A(c, {
      get value() {
        return W();
      },
      autocomplete: !0,
      get options() {
        return e(q);
      },
      getOptionLabel: (I) => I.email,
      getOptionValue: (I) => I._id,
      get disabled() {
        return $();
      },
      get searchPlaceholder() {
        return o(() => R.searchPlaceholder);
      },
      popoverAutoWidth: !0,
      get searchTerm() {
        return e(x);
      },
      set searchTerm(I) {
        i(x, I);
      },
      $$events: {
        change(I) {
          ot.call(this, t, I);
        }
      },
      $$legacy: !0
    });
  }), m(B), h(ne, B), dt(), K();
}
var pl = re("<div><!></div>"), hl = re("<div><!></div>"), ml = re('<div><!> <div><div class="field svelte-1alme8h"><!></div> <div class="binding-control svelte-1alme8h"><!></div></div></div>');
function bl(ne, t) {
  it(t, !1);
  const u = b(), g = b(), K = b(), D = b(), S = b();
  let a = l(t, "filter", 8), q = l(t, "disabled", 8, !1), d = l(t, "bindings", 24, () => []), N = l(t, "allowBindings", 8, !1), W = l(t, "schemaFields", 8), $ = l(t, "panel", 8, void 0), j = l(t, "drawerTitle", 8, void 0), x = l(t, "toReadable", 8, void 0), M = l(t, "toRuntime", 8, void 0), z = l(t, "evaluationContext", 24, () => ({})), f = l(t, "bindingValueType", 24, () => da.BINDING), R = l(t, "useConditionValueControls", 8, !1), se = l(t, "calendarLabels", 24, () => ca("calendar"));
  const H = Ot(), { OperatorOptions: y, FilterValueType: B } = va;
  let C = b();
  const c = (s) => W().find((te) => te.name === s)?.constraints?.inclusion || [], A = (s) => W().find((v) => v.name === s.field), I = (s) => {
    i(K, s.detail);
  }, p = (s) => {
    i(u, s.detail), H("change", {
      value: M() ? M()(d(), e(u)) : e(u)
    });
  }, me = () => {
    H("change", {
      value: M() ? M()(d(), e(K)) : e(K),
      valueType: e(K) ? f() : B.VALUE
    });
  }, we = (s) => !s || !isNaN(new Date(s).valueOf()), Le = (s) => {
    let v = [];
    if (Array.isArray(s))
      v = s;
    else if (s && typeof s == "string")
      v = s.split(",");
    else
      return !s;
    const te = A(a())?.constraints?.inclusion;
    return te?.length ? v.every((ve) => te.includes(ve)) : !0;
  }, L = (s) => s === "false" || s === "true" || s == "", F = (s) => {
    let v = [];
    if (Array.isArray(s))
      v = s;
    else if (s && typeof s == "string")
      v = s.split(",");
    else
      return !s;
    return v.every((te) => te.startsWith("ro_"));
  }, ue = {
    date: we,
    datetime: we,
    bb_reference: F,
    bb_reference_single: F,
    array: Le,
    longform: (s) => !Wt(s),
    options: (s) => !Wt(s) && !Ba(s)?.length,
    boolean: L
  }, O = (s) => {
    const v = ue[a().type];
    return v ? v(s) : !0;
  }, w = (s) => (Array.isArray(s) ? s.join(",") : e(g)) ?? "";
  V(() => n(a()), () => {
    i(u, a()?.value);
  }), V(
    () => (n(x()), n(d()), e(u)),
    () => {
      i(g, x() ? x()(d(), e(u)) : e(u));
    }
  ), V(() => e(u), () => {
    i(K, w(e(u)));
  }), V(() => e(u), () => {
    i(D, Wt(e(u)));
  }), V(() => e(u), () => {
    i(S, O(e(u)));
  }), pt(), ut();
  var ee = ml(), fe = _(ee);
  {
    let s = Q(() => (n(j()), n(a()), o(() => j() || a().field)));
    Ht(
      vl(fe, {
        get title() {
          return e(s);
        },
        forceModal: !0,
        $$events: {
          drawerHide(v) {
            ot.call(this, t, v);
          },
          drawerShow(v) {
            ot.call(this, t, v);
          }
        },
        $$slots: {
          buttons: (v, te) => {
            Yt(v, {
              cta: !0,
              slot: "buttons",
              $$events: {
                click: () => {
                  me(), e(C).hide();
                }
              },
              children: (ve, ge) => {
                kt();
                var J = Nt("Confirm");
                h(ve, J);
              },
              $$slots: { default: !0 }
            });
          },
          body: (v, te) => {
            var ve = ie(), ge = X(ve);
            ua(ge, $, (J, Ne) => {
              Ne(J, {
                slot: "body",
                get value() {
                  return e(K);
                },
                allowJS: !0,
                allowHelpers: !0,
                allowHBS: !0,
                get bindings() {
                  return d();
                },
                get context() {
                  return z();
                },
                $$events: { change: I }
              });
            }), h(v, ve);
          }
        },
        $$legacy: !0
      }),
      (v) => i(C, v),
      () => e(C)
    );
  }
  var de = k(fe, 2);
  let Te;
  var be = _(de), ce = _(be);
  {
    var Ae = (s) => {
      {
        let v = Q(() => e(D) ? "(JavaScript function)" : e(g));
        Lt(s, {
          get disabled() {
            return n(a()), o(() => a().noValue);
          },
          get readonly() {
            return e(D);
          },
          get value() {
            return e(v);
          },
          $$events: { change: p }
        });
      }
    }, at = (s) => {
      var v = pl(), te = _(v);
      {
        var ve = (J) => {
          Lt(J, {
            type: "number",
            get disabled() {
              return n(a()), o(() => a().noValue);
            },
            get value() {
              return e(g);
            },
            $$events: { change: p }
          });
        }, ge = (J) => {
          var Ne = ie(), Y = X(Ne);
          {
            var Z = (Be) => {
              Lt(Be, {
                get disabled() {
                  return n(a()), o(() => a().noValue);
                },
                get value() {
                  return e(g);
                },
                $$events: { change: p }
              });
            }, _e = (Be) => {
              var Ft = ie(), r = X(Ft);
              {
                var P = (ye) => {
                  {
                    let Ke = Q(() => (e(g), o(() => Array.isArray(e(g)) ? e(g) : [])));
                    Ma(ye, {
                      get disabled() {
                        return n(a()), o(() => a().noValue);
                      },
                      get value() {
                        return e(Ke);
                      },
                      onchange: (ct) => p({ detail: ct })
                    });
                  }
                }, pe = (ye) => {
                  var Ke = ie(), ct = X(Ke);
                  {
                    var qe = (Pe) => {
                      {
                        let Se = Q(() => (n(a()), o(() => c(a().field))));
                        ga(Pe, {
                          get disabled() {
                            return n(a()), o(() => a().noValue);
                          },
                          get options() {
                            return e(Se);
                          },
                          get value() {
                            return e(g);
                          },
                          popoverAutoWidth: !0,
                          $$events: { change: p }
                        });
                      }
                    }, lt = (Pe) => {
                      var Se = ie(), ht = X(Se);
                      {
                        var ae = (je) => {
                          {
                            let mt = Q(() => (n(a()), o(() => c(a().field))));
                            tt(je, {
                              get disabled() {
                                return n(a()), o(() => a().noValue);
                              },
                              get options() {
                                return e(mt);
                              },
                              get value() {
                                return e(g);
                              },
                              popoverAutoWidth: !0,
                              wrapText: !0,
                              $$events: { change: p }
                            });
                          }
                        }, Me = (je) => {
                          var mt = ie(), ze = X(mt);
                          {
                            var He = (he) => {
                              {
                                let G = Q(() => (n(a()), o(() => c(a().field))));
                                la(he, {
                                  get disabled() {
                                    return n(a()), o(() => a().noValue);
                                  },
                                  get options() {
                                    return e(G);
                                  },
                                  get value() {
                                    return e(g);
                                  },
                                  popoverAutoWidth: !0,
                                  wrapText: !0,
                                  $$events: { change: p }
                                });
                              }
                            }, Ye = (he) => {
                              var G = ie(), Qe = X(G);
                              {
                                var Ie = (Fe) => {
                                  tt(Fe, {
                                    placeholder: !1,
                                    get disabled() {
                                      return n(a()), o(() => a().noValue);
                                    },
                                    options: [
                                      { label: "True", value: "true" },
                                      { label: "False", value: "false" }
                                    ],
                                    get value() {
                                      return e(g);
                                    },
                                    popoverAutoWidth: !0,
                                    $$events: { change: p }
                                  });
                                }, $e = (Fe) => {
                                  var le = ie(), Oe = X(le);
                                  {
                                    var Re = (De) => {
                                      la(De, {
                                        get disabled() {
                                          return n(a()), o(() => a().noValue);
                                        },
                                        options: [
                                          { label: "True", value: "true" },
                                          { label: "False", value: "false" }
                                        ],
                                        get value() {
                                          return e(g);
                                        },
                                        popoverAutoWidth: !0,
                                        $$events: { change: p }
                                      });
                                    }, bt = (De) => {
                                      var vt = ie(), _t = X(vt);
                                      {
                                        var et = (ke) => {
                                          {
                                            let E = Q(() => (n(a()), o(() => !A(a())?.dateOnly))), Ee = Q(() => (n(a()), o(() => A(a())?.timeOnly)));
                                            $a(ke, {
                                              get disabled() {
                                                return n(a()), o(() => a().noValue);
                                              },
                                              get enableTime() {
                                                return e(E);
                                              },
                                              get timeOnly() {
                                                return e(Ee);
                                              },
                                              get calendarLabels() {
                                                return se();
                                              },
                                              get value() {
                                                return e(g);
                                              },
                                              $$events: { change: p }
                                            });
                                          }
                                        }, Et = (ke) => {
                                          var E = ie(), Ee = X(E);
                                          {
                                            var yt = (rt) => {
                                              {
                                                let Dt = Q(() => (n(a()), o(() => [y.In.value, y.ContainsAny.value].includes(a().operator))));
                                                fl(rt, {
                                                  get multiselect() {
                                                    return e(Dt);
                                                  },
                                                  get disabled() {
                                                    return n(a()), o(() => a().noValue);
                                                  },
                                                  get value() {
                                                    return e(g);
                                                  },
                                                  $$events: { change: p }
                                                });
                                              }
                                            }, Vt = (rt) => {
                                              Lt(rt, { disabled: !0 });
                                            };
                                            U(
                                              Ee,
                                              (rt) => {
                                                n(T), n(a()), o(() => [T.BB_REFERENCE, T.BB_REFERENCE_SINGLE].includes(a().type)) ? rt(yt) : rt(Vt, !1);
                                              },
                                              !0
                                            );
                                          }
                                          h(ke, E);
                                        };
                                        U(
                                          _t,
                                          (ke) => {
                                            n(a()), n(T), o(() => a().type === T.DATETIME) ? ke(et) : ke(Et, !1);
                                          },
                                          !0
                                        );
                                      }
                                      h(De, vt);
                                    };
                                    U(
                                      Oe,
                                      (De) => {
                                        n(a()), n(T), o(() => a().type === T.BOOLEAN) ? De(Re) : De(bt, !1);
                                      },
                                      !0
                                    );
                                  }
                                  h(Fe, le);
                                };
                                U(
                                  Qe,
                                  (Fe) => {
                                    n(a()), n(T), n(R()), o(() => a().type === T.BOOLEAN && R()) ? Fe(Ie) : Fe($e, !1);
                                  },
                                  !0
                                );
                              }
                              h(he, G);
                            };
                            U(
                              ze,
                              (he) => {
                                n(a()), n(T), o(() => a().type === T.OPTIONS) ? he(He) : he(Ye, !1);
                              },
                              !0
                            );
                          }
                          h(je, mt);
                        };
                        U(
                          ht,
                          (je) => {
                            n(a()), n(T), n(R()), o(() => a().type === T.OPTIONS && R()) ? je(ae) : je(Me, !1);
                          },
                          !0
                        );
                      }
                      h(Pe, Se);
                    };
                    U(
                      ct,
                      (Pe) => {
                        n(a()), n(T), n(Gt), o(() => a().type === T.ARRAY || a().type === T.OPTIONS && (a().operator === Gt.ONE_OF || a().operator === Gt.NOT_ONE_OF)) ? Pe(qe) : Pe(lt, !1);
                      },
                      !0
                    );
                  }
                  h(ye, Ke);
                };
                U(
                  r,
                  (ye) => {
                    n(a()), n(T), n(R()), o(() => a().type === T.ARRAY && R() && !c(a().field).length) ? ye(P) : ye(pe, !1);
                  },
                  !0
                );
              }
              h(Be, Ft);
            };
            U(
              Y,
              (Be) => {
                n(T), n(a()), o(() => [
                  T.STRING,
                  T.LONGFORM,
                  T.NUMBER,
                  T.BIGINT,
                  T.FORMULA,
                  T.AI,
                  T.BARCODEQR
                ].includes(a().type)) ? Be(Z) : Be(_e, !1);
              },
              !0
            );
          }
          h(J, Ne);
        };
        U(te, (J) => {
          n(a()), n(T), n(R()), o(() => a().type === T.NUMBER && R()) ? J(ve) : J(ge, !1);
        });
      }
      m(v), h(s, v);
    };
    U(ce, (s) => {
      n(a()), o(() => a().valueType === B.BINDING) ? s(Ae) : s(at, !1);
    });
  }
  m(be);
  var Xe = k(be, 2), Ue = _(Xe);
  {
    var xe = (s) => {
      var v = hl();
      let te;
      var ve = _(v);
      st(ve, { size: "S", weight: "fill", name: "lightning" }), m(v), Ce((ge) => te = Ge(v, 1, "icon svelte-1alme8h", null, te, ge), [() => ({ binding: a().valueType === "Binding" })]), gt("click", v, () => {
        e(C).show();
      }), h(s, v);
    };
    U(Ue, (s) => {
      n(q()), n(N()), n(a()), o(() => !q() && N() && !a().noValue) && s(xe);
    });
  }
  m(Xe), m(de), m(ee), Ce((s) => Te = Ge(de, 1, "field-wrap svelte-1alme8h", null, Te, s), [
    () => ({ bindings: N(), valid: e(S) })
  ]), h(ne, ee), dt();
}
var _l = re('<div class="global-filter-header svelte-1bn7luf"><span> </span> <span class="operator-picker svelte-1bn7luf"><!></span> <span> </span></div>'), yl = re("<div><!> <!> <!> <!> <!></div>"), Ol = re('<div class="group svelte-1bn7luf"><div class="group-header svelte-1bn7luf"><div class="group-options svelte-1bn7luf"><span> </span> <span class="operator-picker svelte-1bn7luf"><!></span> <span> </span></div> <div class="group-actions svelte-1bn7luf"><!> <!></div></div> <div class="filters svelte-1bn7luf"></div></div>'), wl = re('<div class="filter-groups svelte-1bn7luf"></div>'), Tl = re('<div class="empty-filter svelte-1bn7luf"><span>Return</span> <span class="empty-filter-picker svelte-1bn7luf"><!></span> <span> </span></div>'), Al = re('<a target="_blank"><!></a>'), Fl = re('<!> <div class="add-group svelte-1bn7luf"><!> <!></div>', 1), El = re('<!> <!> <!> <div class="filters-footer svelte-1bn7luf"><!></div>', 1), Vl = re("<div><!></div>");
function xl(ne, t) {
  const u = na(t);
  it(t, !1);
  const g = () => Ze(fe, "$appStore", D), K = () => Ze(Ae, "$context", D), [D, S] = It(), a = b(), q = b(), d = b(), N = b(), W = Ot(), {
    OperatorOptions: $,
    DEFAULT_BB_DATASOURCE_ID: j,
    FilterOperator: x,
    OnEmptyFilter: M,
    FilterValueType: z
  } = va;
  let f = l(t, "schemaFields", 12), R = l(t, "filters", 8), se = l(t, "tables", 24, () => []), H = l(t, "datasource", 8), y = l(t, "behaviourFilters", 8, !1), B = l(t, "allowBindings", 8, !1), C = l(t, "allowOnEmpty", 8, !0), c = l(t, "docsURL", 8, "https://docs.budibase.com/docs/searchfilter-data"), A = l(t, "prefix", 8, "Show data which matches"), I = l(t, "filterTypeLabel", 8, "filter"), p = l(t, "drawerTitle", 8, null), me = l(t, "bindingValueType", 24, () => da.BINDING), we = l(t, "useConditionValueControls", 8, !1), Le = l(t, "flagInvalidFields", 8, !1), L = l(t, "bindings", 8), F = l(t, "panel", 8), ue = l(t, "toReadable", 8), O = l(t, "toRuntime", 8), w = l(t, "evaluationContext", 24, () => ({}));
  const ee = Bt("sdk") || {}, { appStore: fe } = ee, de = (r) => Array.isArray(r) ? Wa(r) : Pt(r), Te = Object.values(x).map((r) => ({ value: r, label: za(r) })), be = {
    [M.RETURN_ALL]: "All rows",
    [M.RETURN_NONE]: "No rows"
  }, ce = Object.values(M).map((r) => ({ value: r, label: be[r] })), Ae = Bt("context"), at = "This field may have been deleted or renamed. No rows will be returned until it is updated or removed", Xe = (r, P) => Le() && !!r.field && !P.some((pe) => pe.value === r.field), Ue = (r, P) => Xe(r, P) ? [
    {
      label: r.field,
      value: r.field,
      icon: {
        component: st,
        props: {
          name: "warning",
          size: "M",
          color: "var(--spectrum-global-color-yellow-600)"
        }
      }
    },
    ...P
  ] : P, xe = (r) => {
    const P = r.type;
    ve(r), ge(r), J(r, P);
  }, s = (r) => {
    ge(r), J(r, r.type);
  }, v = (r) => f().find((P) => P.name === r.field), te = (r) => Ha(r?.type ? r : { ...r, type: T.STRING }, r?.field || r?.name, H()), ve = (r) => {
    const P = f().find((pe) => pe.name === r.field);
    r.type = P?.type, r.subtype = P?.subtype, r.formulaType = P?.formulaType, r.constraints = P?.constraints, r.externalType = v(r)?.externalType;
  }, ge = (r) => {
    const P = te(r).map((ye) => ye.value);
    P.includes(r.operator) || (r.operator = P[0] ?? $.Equals.value);
    const pe = [$.Empty.value, $.NotEmpty.value];
    r.noValue = pe.includes(r.operator);
  }, J = (r, P) => {
    if (r.noValue) {
      r.value = null;
      return;
    }
    Array.isArray(r.value) ? (r.valueType !== "Value" || r.type !== T.ARRAY) && (r.value = null) : r.type === T.ARRAY && r.valueType === "Value" ? r.value = [] : P !== r.type && (P === T.BB_REFERENCE || r.type === T.BB_REFERENCE) && (r.value = r.type === T.ARRAY ? [] : null);
  }, Ne = (r) => r == 0 ? "When" : { [x.ANY]: "or", [x.ALL]: "and" }[e(d).logicalOperator], Y = (r, P, pe) => {
    const ye = Pt(r);
    Z({ groupIdx: P, filterIdx: pe, filter: { ...ye } });
  }, Z = (r) => {
    const {
      groupIdx: P,
      filterIdx: pe,
      filter: ye,
      group: Ke,
      addFilter: ct,
      addGroup: qe,
      deleteGroup: lt,
      deleteFilter: Pe,
      logicalOperator: Se,
      onEmptyFilter: ht
    } = r;
    let ae = Pt(e(d)), Me = ae?.groups?.[P];
    Me?.filters?.[pe] ? Pe ? (Me.filters.splice(pe, 1), Me.filters.length === 0 && ae.groups.splice(P, 1)) : ye && (Me.filters[pe] = ye) : Me ? lt ? ae.groups.splice(P, 1) : ct ? Me.filters.push({ valueType: z.VALUE }) : Ke && (ae.groups[P] = { ...Me, ...Ke }) : qe ? (ae?.groups?.length || (ae = {
      logicalOperator: Ua.ALL,
      onEmptyFilter: Ga.RETURN_NONE,
      groups: []
    }), ae.groups.push({
      logicalOperator: qa.ANY,
      filters: [{ valueType: z.VALUE }]
    })) : Se ? ae = { ...ae, logicalOperator: Se } : ht && (ae = { ...ae, onEmptyFilter: ht }), ae = ae.groups.length ? ae : null, W("change", ae);
  };
  V(() => g(), () => {
    i(a, Ia(fe ? g().application?.translationOverrides : void 0));
  }), V(() => e(a), () => {
    i(q, ca("calendar", e(a)));
  }), V(() => n(R()), () => {
    i(d, de(R()));
  }), V(
    () => (n(se()), n(H()), n(f())),
    () => {
      se().find((r) => r._id === H()?.tableId && r.sourceId === j) && !f().some((r) => r.name === "_id") && f([...f(), { name: "_id", type: "string" }]);
    }
  ), V(() => n(f()), () => {
    i(N, (f() || []).filter((r) => !r.calculationType).map((r) => ({ label: r.displayName || r.name, value: r.name })));
  }), pt(), ut();
  var _e = Vl();
  let Be;
  var Ft = _(_e);
  aa(Ft, {
    noPadding: !0,
    children: (r, P) => {
      var pe = ie(), ye = X(pe);
      {
        var Ke = (qe) => {
          var lt = El(), Pe = X(lt);
          ft(Pe, t, "filtering-hero-content", {}, null);
          var Se = k(Pe, 2);
          {
            var ht = (ze) => {
              var He = _l(), Ye = _(He), he = _(Ye, !0);
              m(Ye);
              var G = k(Ye, 2), Qe = _(G);
              {
                let Fe = Q(() => (e(d), o(() => e(d)?.logicalOperator)));
                tt(Qe, {
                  get value() {
                    return e(Fe);
                  },
                  get options() {
                    return Te;
                  },
                  getOptionLabel: (le) => le.label,
                  getOptionValue: (le) => le.value,
                  placeholder: !1,
                  popoverAutoWidth: !0,
                  $$events: {
                    change: (le) => {
                      Z({ logicalOperator: le.detail });
                    }
                  }
                });
              }
              m(G);
              var Ie = k(G, 2), $e = _(Ie);
              m(Ie), m(He), Ce(() => {
                nt(he, A()), nt($e, `of the following ${I() ?? ""} groups:`);
              }), h(ze, He);
            };
            U(Se, (ze) => {
              e(d), o(() => e(d)?.groups?.length) && ze(ht);
            });
          }
          var ae = k(Se, 2);
          {
            var Me = (ze) => {
              var He = wl();
              Ut(
                He,
                5,
                () => (e(d), o(() => e(d)?.groups)),
                qt,
                (Ye, he, G) => {
                  var Qe = Ol(), Ie = _(Qe), $e = _(Ie), Fe = _($e), le = _(Fe, !0);
                  m(Fe);
                  var Oe = k(Fe, 2), Re = _(Oe);
                  {
                    let ke = Q(() => (e(he), o(() => e(he)?.logicalOperator)));
                    tt(Re, {
                      get value() {
                        return e(ke);
                      },
                      get options() {
                        return Te;
                      },
                      getOptionLabel: (E) => E.label,
                      getOptionValue: (E) => E.value,
                      placeholder: !1,
                      popoverAutoWidth: !0,
                      $$events: {
                        change: (E) => {
                          Z({ groupIdx: G, group: { logicalOperator: E.detail } });
                        }
                      }
                    });
                  }
                  m(Oe);
                  var bt = k(Oe, 2), De = _(bt);
                  m(bt), m($e);
                  var vt = k($e, 2), _t = _(vt);
                  st(_t, {
                    name: "plus",
                    hoverable: !0,
                    hoverColor: "var(--ink)",
                    $$events: {
                      click: () => {
                        Z({ groupIdx: G, addFilter: !0 });
                      }
                    }
                  });
                  var et = k(_t, 2);
                  st(et, {
                    name: "trash",
                    hoverable: !0,
                    hoverColor: "var(--ink)",
                    $$events: {
                      click: () => {
                        Z({ groupIdx: G, deleteGroup: !0 });
                      }
                    }
                  }), m(vt), m(Ie);
                  var Et = k(Ie, 2);
                  Ut(Et, 5, () => (e(he), o(() => e(he).filters)), qt, (ke, E, Ee) => {
                    var yt = yl();
                    Ge(yt, 1, "filter svelte-1bn7luf", null, {}, { "has-extra-column": !!u["extra-column"] });
                    var Vt = _(yt);
                    {
                      var rt = (oe) => {
                        var Ve = ie(), We = X(Ve);
                        ft(
                          We,
                          t,
                          "field-column",
                          {
                            get filter() {
                              return e(E);
                            },
                            groupIdx: G,
                            filterIdx: Ee,
                            onUpdate: (Je) => Y(Je, G, Ee),
                            sanitizeOperator: ge,
                            sanitizeValue: J
                          },
                          null
                        ), h(oe, Ve);
                      }, Dt = (oe) => {
                        {
                          let Ve = Q(() => (e(E), e(N), o(() => Xe(e(E), e(N)) ? at : "")));
                          ja(oe, {
                            get text() {
                              return e(Ve);
                            },
                            children: (We, Je) => {
                              {
                                let xt = Q(() => (e(E), e(N), o(() => Ue(e(E), e(N)))));
                                tt(We, {
                                  get value() {
                                    return e(E), o(() => e(E).field);
                                  },
                                  get options() {
                                    return e(xt);
                                  },
                                  placeholder: "Column",
                                  popoverAutoWidth: !0,
                                  $$events: {
                                    change: (ba) => {
                                      const Xt = { ...e(E), field: ba.detail };
                                      xe(Xt), Y(Xt, G, Ee);
                                    }
                                  }
                                });
                              }
                            },
                            $$slots: { default: !0 }
                          });
                        }
                      };
                      U(Vt, (oe) => {
                        o(() => u["field-column"]) ? oe(rt) : oe(Dt, !1);
                      });
                    }
                    var Qt = k(Vt, 2);
                    {
                      let oe = Q(() => (e(E), o(() => e(E).operator || $.Equals.value))), Ve = Q(() => (e(E), o(() => !e(E).field && !u["field-column"]))), We = Q(() => (e(E), o(() => te(e(E)))));
                      tt(Qt, {
                        get value() {
                          return e(oe);
                        },
                        get disabled() {
                          return e(Ve);
                        },
                        get options() {
                          return e(We);
                        },
                        placeholder: !1,
                        popoverAutoWidth: !0,
                        $$events: {
                          change: (Je) => {
                            const xt = { ...e(E), operator: Je.detail };
                            s(xt), Y(xt, G, Ee);
                          }
                        }
                      });
                    }
                    var Jt = k(Qt, 2);
                    {
                      var fa = (oe) => {
                        var Ve = ie(), We = X(Ve);
                        ft(
                          We,
                          t,
                          "extra-column",
                          {
                            get filter() {
                              return e(E);
                            },
                            groupIdx: G,
                            filterIdx: Ee,
                            onUpdate: (Je) => Y(Je, G, Ee),
                            sanitizeOperator: ge,
                            sanitizeValue: J
                          },
                          null
                        ), h(oe, Ve);
                      };
                      U(Jt, (oe) => {
                        o(() => u["extra-column"]) && oe(fa);
                      });
                    }
                    var Zt = k(Jt, 2);
                    {
                      var pa = (oe) => {
                        var Ve = ie(), We = X(Ve);
                        ft(
                          We,
                          t,
                          "value-column",
                          {
                            get filter() {
                              return e(E);
                            },
                            groupIdx: G,
                            filterIdx: Ee,
                            onUpdate: (Je) => Y(Je, G, Ee),
                            sanitizeOperator: ge,
                            sanitizeValue: J
                          },
                          null
                        ), h(oe, Ve);
                      }, ha = (oe) => {
                        {
                          let Ve = Q(() => (e(E), o(() => !e(E).field && !u["field-column"]))), We = Q(() => (e(E), o(() => ({ ...e(E) }))));
                          bl(oe, {
                            placeholder: "Value",
                            get disabled() {
                              return e(Ve);
                            },
                            get drawerTitle() {
                              return p();
                            },
                            get allowBindings() {
                              return B();
                            },
                            get filter() {
                              return e(We);
                            },
                            get schemaFields() {
                              return f();
                            },
                            get calendarLabels() {
                              return e(q);
                            },
                            get bindings() {
                              return L();
                            },
                            get panel() {
                              return F();
                            },
                            get toReadable() {
                              return ue();
                            },
                            get toRuntime() {
                              return O();
                            },
                            get evaluationContext() {
                              return w();
                            },
                            get bindingValueType() {
                              return me();
                            },
                            get useConditionValueControls() {
                              return we();
                            },
                            $$events: {
                              change: (Je) => {
                                Y({ ...e(E), ...Je.detail }, G, Ee);
                              }
                            }
                          });
                        }
                      };
                      U(Zt, (oe) => {
                        o(() => u["value-column"]) ? oe(pa) : oe(ha, !1);
                      });
                    }
                    var ma = k(Zt, 2);
                    oa(ma, {
                      size: "M",
                      icon: "trash",
                      $$events: {
                        click: () => {
                          Z({ groupIdx: G, filterIdx: Ee, deleteFilter: !0 });
                        }
                      }
                    }), m(yt), h(ke, yt);
                  }), m(Et), m(Qe), Ce(
                    (ke) => {
                      nt(le, ke), nt(De, `of the following ${I() ?? ""}s are matched:`);
                    },
                    [
                      () => (e(d), o(() => Ne(G, e(d).logicalOperator)))
                    ]
                  ), h(Ye, Qe);
                }
              ), m(He), h(ze, He);
            };
            U(ae, (ze) => {
              e(d), o(() => e(d)?.groups?.length) && ze(Me);
            });
          }
          var je = k(ae, 2), mt = _(je);
          aa(mt, {
            noPadding: !0,
            children: (ze, He) => {
              var Ye = Fl(), he = X(Ye);
              {
                var G = (le) => {
                  var Oe = Tl(), Re = k(_(Oe), 2), bt = _(Re);
                  {
                    let _t = Q(() => (e(d), o(() => e(d)?.onEmptyFilter)));
                    tt(bt, {
                      get value() {
                        return e(_t);
                      },
                      get options() {
                        return ce;
                      },
                      getOptionLabel: (et) => et.label,
                      getOptionValue: (et) => et.value,
                      placeholder: !1,
                      popoverAutoWidth: !0,
                      $$events: {
                        change: (et) => {
                          Z({ onEmptyFilter: et.detail });
                        }
                      }
                    });
                  }
                  m(Re);
                  var De = k(Re, 2), vt = _(De);
                  m(De), m(Oe), Ce(() => nt(vt, `when all ${I() ?? ""}s are empty`)), h(le, Oe);
                };
                U(he, (le) => {
                  n(y()), n(C()), e(d), o(() => y() && C() && e(d)?.groups?.length) && le(G);
                });
              }
              var Qe = k(he, 2), Ie = _(Qe);
              Yt(Ie, {
                icon: "plus-circle",
                size: "M",
                secondary: !0,
                $$events: {
                  click: () => {
                    Z({ addGroup: !0 });
                  }
                },
                children: (le, Oe) => {
                  kt();
                  var Re = Nt();
                  Ce(() => nt(Re, `Add ${I() ?? ""} group`)), h(le, Re);
                },
                $$slots: { default: !0 }
              });
              var $e = k(Ie, 2);
              {
                var Fe = (le) => {
                  var Oe = Al(), Re = _(Oe);
                  st(Re, {
                    name: "question",
                    color: "var(--spectrum-global-color-gray-600)"
                  }), m(Oe), Ce(() => jt(Oe, "href", c())), h(le, Oe);
                };
                U($e, (le) => {
                  c() && le(Fe);
                });
              }
              m(Qe), h(ze, Ye);
            },
            $$slots: { default: !0 }
          }), m(je), h(qe, lt);
        }, ct = (qe) => {
          Da(qe, {
            size: "S",
            children: (lt, Pe) => {
              kt();
              var Se = Nt("None of the table column can be used for filtering.");
              h(lt, Se);
            },
            $$slots: { default: !0 }
          });
        };
        U(ye, (qe) => {
          e(N), o(() => e(N)?.length) ? qe(Ke) : qe(ct, !1);
        });
      }
      h(r, pe);
    },
    $$slots: { default: !0 }
  }), m(_e), Ce((r) => Be = Ge(_e, 1, "container svelte-1bn7luf", null, Be, r), [() => ({ mobile: K()?.device?.mobile })]), h(ne, _e), dt(), S();
}
var Cl = re("<!> <!>", 1);
function kl(ne, t) {
  it(t, !1);
  const u = () => Ze(M, "$component", g), [g, K] = It(), D = b(), S = b(), a = b(), q = b(), d = b(), N = b(), W = b();
  let $ = l(t, "dataProvider", 8), j = l(t, "allowedFields", 8), x = l(t, "size", 8, "M");
  const M = Bt("component"), { builderStore: z, ActionTypes: f, getAction: R, fetchDatasourceSchema: se } = Bt("sdk");
  let H = b(), y = b(), B = b(), C = b(!1), c = b();
  async function A(F) {
    F && i(c, await se(F, { enrichRelationships: !0 })), i(C, !0);
  }
  function I(F, ue) {
    if (!e(C))
      return {};
    let O = {};
    return ue?.length ? ue?.forEach((w) => {
      F?.[w.name] ? (O[w.name] = F[w.name], O[w.name].displayName = w.displayName) : F?.[w] && (O[w] = F[w]);
    }) : O = F || {}, Object.values(O || {}).filter((w) => !Za.includes(w.type)).concat(e(a) ? [{ name: "_id", type: "string" }] : []);
  }
  const p = () => {
    ia(z).inBuilder || (i(y, e(B) ? Pt(e(B)) : null), e(H).show());
  }, me = () => {
    i(B, Xa(e(y)));
  };
  sa(() => {
    e(d)?.(u().id);
  }), V(() => n($()), () => {
    i(D, $()?.id);
  }), V(() => n($()), () => {
    i(S, $()?.datasource);
  }), V(() => e(S), () => {
    i(a, ["table", "link", "viewV2"].includes(e(S)?.type));
  }), V(() => e(D), () => {
    i(q, R(e(D), f.AddDataProviderQueryExtension));
  }), V(() => e(D), () => {
    i(d, R(e(D), f.RemoveDataProviderQueryExtension));
  }), V(() => e(S), () => {
    A(e(S));
  }), V(() => (e(c), n(j())), () => {
    i(N, I(e(c), j()));
  }), V(() => e(B), () => {
    i(W, e(B)?.groups?.reduce(
      (F, ue) => (F += ue?.filters?.length || 0, F),
      0
    ));
  }), V(
    () => (e(W), e(B), e(q), u(), e(d)),
    () => {
      if (e(W)) {
        const F = Ya(e(B));
        delete F.onEmptyFilter, e(q)?.(u().id, F);
      } else
        e(d)?.(u().id);
    }
  ), pt(), ut();
  var we = ie(), Le = X(we);
  {
    var L = (F) => {
      var ue = Cl(), O = X(ue);
      {
        let ee = Q(() => (e(B), o(() => e(B)?.groups?.length > 0)));
        tl(O, {
          onClick: p,
          icon: "ri-filter-3-line",
          text: "Filter",
          get size() {
            return x();
          },
          type: "secondary",
          quiet: !0,
          get active() {
            return e(ee);
          }
        });
      }
      var w = k(O, 2);
      Ht(
        Qa(w, {
          children: (ee, fe) => {
            Ja(ee, {
              title: "Edit filters",
              size: "XL",
              onConfirm: me,
              children: (de, Te) => {
                xl(de, {
                  get filters() {
                    return e(y);
                  },
                  get schemaFields() {
                    return e(N);
                  },
                  get datasource() {
                    return e(S);
                  },
                  filtersLabel: null,
                  $$events: {
                    change: (be) => {
                      i(y, be.detail);
                    }
                  }
                });
              },
              $$slots: { default: !0 }
            });
          },
          $$slots: { default: !0 },
          $$legacy: !0
        }),
        (ee) => i(H, ee),
        () => e(H)
      ), h(F, ue);
    };
    U(Le, (F) => {
      e(C) && F(L);
    });
  }
  h(ne, we), dt(), K();
}
export {
  kl as default
};
