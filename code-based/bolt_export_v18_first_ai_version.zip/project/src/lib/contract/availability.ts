import { ContractBooking } from './data';
import { ContractInput, ReasonCode, validateInput } from './validation';

export interface ContractResult {
  available: boolean;
  reasonCode: ReasonCode;
  message: string;
}

function toLabel(min: number): string {
  const h = String(Math.floor(min / 60)).padStart(2, '0');
  const m = String(min % 60).padStart(2, '0');
  return `${h}:${m}`;
}

export function minutesFromDayStart(date: Date): number {
  return date.getHours() * 60 + date.getMinutes();
}

// Pure: validation first, then ROOM_BLOCKED, then OVERLAP (touching edges are
// not an overlap), else AVAILABLE. Never modifies the bookings array.
export function checkContract(
  input: ContractInput,
  now: Date,
  bookings: readonly ContractBooking[]
): ContractResult {
  const error = validateInput(input, now);
  if (error) {
    return { available: false, reasonCode: error.code, message: error.message };
  }

  if (input.roomBlocked) {
    return {
      available: false,
      reasonCode: 'ROOM_BLOCKED',
      message: 'Unavailable: the room is blocked.',
    };
  }

  const start = minutesFromDayStart(new Date(input.start));
  const end = start + input.durationMinutes;
  const conflict = bookings.find(
    (b) => start < b.end && b.start < end
  );
  if (conflict) {
    return {
      available: false,
      reasonCode: 'OVERLAP',
      message: `Unavailable: overlaps with "${conflict.title}" (${toLabel(conflict.start)}–${toLabel(conflict.end)}).`,
    };
  }

  return {
    available: true,
    reasonCode: 'AVAILABLE',
    message: `Available: Room A-101 is free from ${toLabel(start)} to ${toLabel(end)}.`,
  };
}
